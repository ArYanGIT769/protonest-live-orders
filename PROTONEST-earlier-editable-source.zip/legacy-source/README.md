# PROTONEST website

Deploy-ready quotation website for PROTONEST with a responsive dark blue interface, service filtering, a three-step RFQ wizard, indicative estimates, technical-file upload, printable quotations, WhatsApp hand-off, and email delivery through FormSubmit.

## Preview locally

Opening `index.html` directly is not enough for a real form test. Run the site through the included development server:

```bash
npm install
npm run dev
```

Open the address shown in the terminal.

## Build for deployment

```bash
npm run build
```

Upload the contents of the generated `dist` folder to a static website host. The exported website itself does not include a Bolt watermark.

## One-time email activation

The quote form sends RFQs to `protonestdesign@gmail.com` through FormSubmit. After publishing:

1. Submit one test quotation from the live website.
2. Open the activation email sent to `protonestdesign@gmail.com` and confirm the form.
3. Submit a second test quotation and verify both the business notification and customer auto-response.

Until that confirmation is completed, FormSubmit sends activation messages instead of normal RFQ emails. Check the spam folder if the activation email does not appear.

## Important settings

- Email: `protonestdesign@gmail.com`
- Phone and WhatsApp: `+91 97521 28113`
- Address: `SGSITS Campus, Indore, Madhya Pradesh`
- Working hours: `Monday–Saturday, 10:00 AM–6:00 PM IST`
- Maximum attachment size: 10 MB
- Accepted files: STL, STEP, STP, OBJ, 3MF, DXF, DWG, PDF, JPG, PNG, and ZIP
- Prices shown by the calculator are indicative and require technical review.

Contact information and price rules are near the top of `script.js` for easy editing.
