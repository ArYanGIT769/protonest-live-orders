/* =========================================================
   PROTONEST — Engineering Services Website
   ========================================================= */

/* ====== CONFIG: Contact details ====== */
const CONTACT = {
  email: "protonestdesign@gmail.com",
  phone: "+91 97521 28113",
  phoneLink: "tel:+919752128113",
  whatsapp: "919752128113",
  whatsappDisplay: "+91 97521 28113",
  whatsappLink: "https://wa.me/919752128113",
  location: "SGSITS Campus, Indore, Madhya Pradesh",
  hours: "Mon–Sat, 10:00 AM – 6:00 PM IST",
};

/* ====== CONFIG: FormSubmit admin email ====== */
const FORMSUBMIT_EMAIL = "protonestdesign@gmail.com";

/* ====== Pricing configuration ====== */
const PRICING = {
  instant: {
    "3d-printing":           { base: 500,  qty: 150, label: "3D Printing" },
    "sla-resin":             { base: 800,  qty: 250, label: "SLA / Resin Printing" },
    "filament-supply":       { base: 350,  qty: 200, label: "3D Printer Filament Supply" },
    "printer-repair":        { base: 600,  qty: 0,   label: "3D Printer Repair" },
    "college-project":       { base: 1200, qty: 300, label: "College Model & Project Service" },
  },
  complexity: { simple: 1.0, medium: 1.4, complex: 1.9 },
  urgentMultiplier: 1.35,
  rangeMargin: 0.22,
};

/* ====== Service definitions ====== */
const SERVICES = [
  { id: "3d-printing",      name: "3D Printing",                     desc: "FDM 3D printing in PLA, ABS, PETG and engineering-grade materials for functional prototypes and end-use parts.", instant: true, category: "manufacturing" },
  { id: "sla-resin",        name: "SLA / Resin Printing",            desc: "High-resolution resin printing for smooth surfaces, fine details and precision jewellery or dental models.", instant: true, category: "manufacturing" },
  { id: "cad-design",       name: "3D CAD Designing",                desc: "Professional 3D CAD modelling from sketches, references or reverse-engineered scan data.", instant: false, category: "design" },
  { id: "3d-scanning",      name: "3D Scanning & Reverse Engineering", desc: "3D scanning and reverse engineering of physical parts into accurate, editable digital models.", instant: false, category: "design" },
  { id: "product-design",   name: "Product Design Support",         desc: "End-to-end product design support from concept development to design for manufacturing.", instant: false, category: "design" },
  { id: "aviation-design",  name: "Aviation Design Support",        desc: "Design and prototyping support for aviation components.", instant: false, category: "design", note: "Design and prototyping support only. Regulatory certification is subject to project-specific review." },
  { id: "medical-design",   name: "Medical Equipment Design Support", desc: "Design and prototyping support for medical device enclosures and assemblies.", instant: false, category: "design", note: "Design and prototyping support only. Regulatory certification is subject to project-specific review." },
  { id: "laser-cutting",    name: "Laser Cutting",                  desc: "Precision laser cutting and engraving in sheet metal, acrylic, wood and other materials.", instant: false, category: "manufacturing" },
  { id: "mould-design",     name: "Mould Design & Fabrication",     desc: "Injection mould design and fabrication for production runs and bridge tooling.", instant: false, category: "manufacturing" },
  { id: "cnc-fabrication",  name: "CNC Fabrication",                desc: "CNC milling and turning for high-accuracy metal and plastic components.", instant: false, category: "manufacturing" },
  { id: "composite-mfg",    name: "Composite Material Manufacturing", desc: "Custom composite material manufacturing for lightweight, high-strength applications.", instant: false, category: "materials" },
  { id: "carbon-fibre",     name: "Carbon Fibre Manufacturing",    desc: "Carbon fibre lay-up, curing and finishing for aerospace, automotive and sport applications.", instant: false, category: "materials" },
  { id: "glass-fibre",      name: "Glass Fibre Manufacturing",      desc: "Glass fibre / FRP moulding and fabrication for durable, corrosion-resistant components.", instant: false, category: "materials" },
  { id: "plastic-moulding",  name: "Plastic Moulding",               desc: "Injection and blow moulding for production-grade plastic parts in various polymers.", instant: false, category: "manufacturing" },
  { id: "filament-supply",   name: "3D Printer Filament Supply",     desc: "Quality PLA, ABS, PETG, TPU and specialty filaments in multiple colours and diameters.", instant: true, category: "materials" },
  { id: "printer-repair",    name: "3D Printer Repair",              desc: "Diagnostic, maintenance and repair services for FDM and resin 3D printers.", instant: true, category: "repair" },
  { id: "college-project",  name: "College Model & Project Service", desc: "Engineering college models, working prototypes and academic project support with documentation.", instant: true, category: "student" },
  { id: "design-selling",   name: "Design Selling & Licensing",     desc: "Original design selling and licensing for ready-to-manufacture CAD models and product concepts.", instant: false, category: "design" },
];

const SERVICE_FILTERS = [
  { id: "all",           label: "All" },
  { id: "manufacturing", label: "Manufacturing" },
  { id: "design",        label: "Design" },
  { id: "materials",    label: "Materials" },
  { id: "repair",        label: "Repair" },
  { id: "student",       label: "Student Projects" },
];

/* ====== Why PROTONEST data ====== */
const WHY_PROTONEST = [
  { icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-5 9 5v8l-9 5-9-5z"/><path d="M3 9l9 5 9-5"/></svg>', title: "One Engineering Workflow", desc: "From concept and CAD to prototype and production&mdash;everything in a single streamlined process." },
  { icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h10"/></svg>', title: "Flexible Project Support", desc: "Whether you need one prototype or a small production batch, we adapt to your project scope." },
  { icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>', title: "Clear Technical Communication", desc: "Our engineers review every submission and explain feasibility, materials and timelines in plain language." },
  { icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2v20M2 12h20"/><circle cx="12" cy="12" r="9"/></svg>', title: "From Prototype to Production", desc: "Start with a single prototype and scale to production-ready components with the same engineering team." },
];

/* ====== Industries data ====== */
const INDUSTRIES = [
  { name: "Automotive",          icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12l2-6h14l2 6M3 12v6h2v-2h14v2h2v-6M3 12h18"/><circle cx="7" cy="14" r="1" fill="currentColor"/><circle cx="17" cy="14" r="1" fill="currentColor"/></svg>' },
  { name: "Aerospace",            icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2l3 8h6l-5 4 2 8-6-4-6 4 2-8-5-4h6z"/></svg>', note: "Design and prototyping support only. Regulatory certification is subject to project-specific review." },
  { name: "Medical Devices",     icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v18M3 12h18"/><rect x="9" y="9" width="6" height="6" rx="1"/></svg>', note: "Design and prototyping support only. Regulatory certification is subject to project-specific review." },
  { name: "Robotics",             icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 4v4M8 14h.01M16 14h.01M9 18h6"/></svg>' },
  { name: "Consumer Products",    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-5 9 5v8l-9 5-9-5z"/><path d="M3 9l9 5 9-5"/></svg>' },
  { name: "Industrial Equipment", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16v16H4z"/><path d="M8 8h8v8H8z"/><circle cx="12" cy="12" r="2"/></svg>' },
  { name: "Education",            icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-5 9 5-9 5z"/><path d="M7 11v5l5 3 5-3v-5"/></svg>' },
];

/* ====== SVG icons for services ====== */
const ICONS = {
  "3d-printing":      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-5 9 5v8l-9 5-9-5z"/><path d="M3 9l9 5 9-5M12 14v8"/></svg>',
  "sla-resin":        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>',
  "cad-design":       '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/></svg>',
  "3d-scanning":      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 7V4h3M21 7V4h-3M3 17v3h3M21 17v3h-3"/><circle cx="12" cy="12" r="4" stroke-dasharray="2 2"/></svg>',
  "product-design":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2l9 5v10l-9 5-9-5V7z"/><path d="M12 12l9-5M12 12v10M12 12L3 7"/></svg>',
  "aviation-design":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2l3 8h6l-5 4 2 8-6-4-6 4 2-8-5-4h6z"/></svg>',
  "medical-design":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v18M3 12h18"/></svg>',
  "laser-cutting":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v6M12 15v6M3 12h6M15 12h6"/><circle cx="12" cy="12" r="2" fill="currentColor"/></svg>',
  "mould-design":     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16v16H4z"/><path d="M8 8h8v8H8z"/></svg>',
  "cnc-fabrication":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><path d="M12 4v8l5 3"/></svg>',
  "composite-mfg":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 8l9-5 9 5-9 5z"/><path d="M3 12l9 5 9-5M3 16l9 5 9-5"/></svg>',
  "carbon-fibre":     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4l16 16M20 4L4 20M4 12h16M12 4v16"/></svg>',
  "glass-fibre":      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18M3 14h18"/></svg>',
  "plastic-moulding":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 8l8-4 8 4v8l-8 4-8-4z"/><circle cx="12" cy="12" r="3"/></svg>',
  "filament-supply":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="8" cy="10" r="5"/><circle cx="16" cy="10" r="5"/><path d="M12 10v8"/></svg>',
  "printer-repair":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 8h18v8H3z"/><path d="M7 8V3h10v5M7 16h10v5H7z"/><circle cx="18" cy="11" r="1" fill="currentColor"/></svg>',
  "college-project":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-5 9 5-9 5z"/><path d="M7 11v5l5 3 5-3v-5"/></svg>',
  "design-selling":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 7l9-4 9 4-9 4z"/><path d="M3 7v10l9 4 9-4V7"/></svg>',
};

/* ====== FAQ data ====== */
const FAQS = [
  { q: "How do PROTONEST quotations work?",
    a: "After you select a service and enter your project details, our calculator provides an indicative price range based on base price, quantity, complexity and delivery speed. The final price is confirmed after our engineering team reviews your design and technical requirements." },
  { q: "Which file formats can I upload?",
    a: "We accept STL, STEP, STP, OBJ, 3MF, DXF, DWG, PDF, JPG, PNG and ZIP files. The maximum total attachment size is 10 MB. For larger files, please mention it in your description and we will share an upload link." },
  { q: "Is the indicative estimate the final price?",
    a: "No. The indicative estimate gives you a budgetary range before commitment. The final price is confirmed after technical review of your design, material specifications, tolerances and finishing requirements." },
  { q: "How long does delivery take?",
    a: "Standard delivery timelines depend on the service, quantity and complexity. 3D printing and simple parts are typically ready in 2–5 working days, while CNC, moulding and composite work may take 1–3 weeks. Urgent delivery is available for select services at an additional charge." },
  { q: "How do you protect design confidentiality?",
    a: "Quotation details and attachments are delivered to PROTONEST through our form-delivery provider for technical review. You retain ownership of the files you submit. For confidential or NDA-controlled work, contact us before uploading so we can agree on the appropriate transfer method." },
  { q: "Do you support student and college projects?",
    a: "Yes. We provide dedicated support for engineering college models, working prototypes and academic projects. Our college project service includes design assistance, fabrication and basic documentation to help you present your work." },
];

/* ====== State ====== */
let selectedServiceId = null;
let currentStep = 1;
let projectData = {};
let quoteRef = null;
let quoteEstimate = null;
let activeFilter = "all";
let lastFocusedElement = null;

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_FILE_EXTENSIONS = [
  ".stl", ".step", ".stp", ".obj", ".3mf", ".dxf", ".dwg",
  ".pdf", ".jpg", ".jpeg", ".png", ".zip",
];

/* ====== DOM helpers ====== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

/* ====== Init ====== */
document.addEventListener("DOMContentLoaded", () => {
  populateContact();
  renderWhyProtonest();
  renderServiceFilters();
  renderServices();
  renderServiceSelect();
  populateQuickQuote();
  renderIndustries();
  renderFAQs();
  setupHeader();
  setupNav();
  setupModal();
  setupQuickQuote();
  setupQuoteWizard();
  setupFileInput();
  setupSummaryToggle();
  setupFieldValidation();
  setMinimumDeliveryDate();
  setupBackToTop();
  setupReveal();
  $("#footer-year").textContent = new Date().getFullYear();
});

window.addEventListener("pageshow", () => {
  const submitButton = $("#submit-rfq");
  if (submitButton) {
    submitButton.textContent = "Submit RFQ & Proceed";
    submitButton.disabled = false;
  }
});

/* ====== Contact info ====== */
function populateContact() {
  const emailEl = $("#contact-email");
  emailEl.textContent = CONTACT.email;
  emailEl.href = `mailto:${CONTACT.email}`;

  const phoneEl = $("#contact-phone");
  phoneEl.textContent = CONTACT.phone;
  phoneEl.href = CONTACT.phoneLink;

  const waEl = $("#contact-whatsapp");
  waEl.textContent = CONTACT.whatsappDisplay;
  waEl.href = CONTACT.whatsappLink;

  $("#contact-location").textContent = CONTACT.location;
  $("#contact-hours").textContent = CONTACT.hours;
}

/* ====== Why PROTONEST ====== */
function renderWhyProtonest() {
  const grid = $("#why-grid");
  grid.innerHTML = WHY_PROTONEST.map((w) => `
    <article class="why-card reveal">
      <div class="why-icon">${w.icon}</div>
      <h3 class="why-title">${w.title}</h3>
      <p class="why-desc">${w.desc}</p>
    </article>
  `).join("");
}

/* ====== Service filters ====== */
function renderServiceFilters() {
  const container = $("#service-filters");
  container.innerHTML = SERVICE_FILTERS.map((f) => `
    <button class="filter-btn ${f.id === "all" ? "active" : ""}" data-filter="${f.id}" role="tab" aria-selected="${f.id === "all"}">${f.label}</button>
  `).join("");

  $$(".filter-btn", container).forEach((btn) => {
    btn.addEventListener("click", () => {
      activeFilter = btn.dataset.filter;
      $$(".filter-btn", container).forEach((b) => {
        b.classList.toggle("active", b === btn);
        b.setAttribute("aria-selected", String(b === btn));
      });
      filterServices();
    });
  });
}

function filterServices() {
  $$(".service-card", $("#service-grid")).forEach((card) => {
    if (activeFilter === "all" || card.dataset.category === activeFilter) {
      card.style.display = "";
    } else {
      card.style.display = "none";
    }
  });
}

/* ====== Service cards ====== */
function renderServices() {
  const grid = $("#service-grid");
  grid.innerHTML = SERVICES.map((s) => `
    <article class="service-card reveal" data-category="${s.category}">
      <div class="service-icon">${ICONS[s.id] || ICONS["cad-design"]}</div>
      <h3 class="service-name">${s.name}</h3>
      <p class="service-desc">${s.desc}</p>
      ${s.note ? `<p class="service-note">${s.note}</p>` : ""}
      <div class="service-actions">
        <button class="btn btn-ghost btn-sm" data-service-detail="${s.id}" aria-expanded="false">View Details</button>
        <button class="btn btn-cta btn-sm" data-quote-service="${s.id}">Get Quote</button>
      </div>
    </article>
  `).join("");

  $$("[data-quote-service]", grid).forEach((btn) => {
    btn.addEventListener("click", () => openQuote(btn.dataset.quoteService));
  });

  $$("[data-service-detail]", grid).forEach((btn) => {
    btn.addEventListener("click", () => showServiceDetail(btn));
  });
}

/* ====== Service detail expansion ====== */
function showServiceDetail(button) {
  const card = button.closest(".service-card");
  const expanded = card.classList.toggle("expanded");
  button.setAttribute("aria-expanded", String(expanded));
  button.textContent = expanded ? "Show Less" : "View Details";
}

/* ====== Service select (modal step 1) ====== */
function renderServiceSelect() {
  const sel = $("#service-select");
  sel.innerHTML = SERVICES.map((s) => `
    <label class="service-option" data-service-option="${s.id}">
      <input type="radio" name="modal-service" value="${s.id}" />
      <span class="service-option-icon">${ICONS[s.id] || ICONS["cad-design"]}</span>
      <span>${s.name}</span>
    </label>
  `).join("");

  $$(".service-option", sel).forEach((opt) => {
    opt.addEventListener("click", () => {
      selectService(opt.dataset.serviceOption);
    });
  });
}

function selectService(serviceId) {
  if (!SERVICES.some((service) => service.id === serviceId)) return;
  selectedServiceId = serviceId;
  $$(".service-option", $("#service-select")).forEach((option) => {
    const selected = option.dataset.serviceOption === serviceId;
    option.classList.toggle("selected", selected);
    option.querySelector("input").checked = selected;
  });
  $('[data-step-next]', $("#quote-modal")).disabled = false;
}

/* ====== Quick quote ====== */
function populateQuickQuote() {
  const select = $("#qq-service");
  select.innerHTML = '<option value="">Select a service</option>' + SERVICES.map(
    (service) => `<option value="${service.id}">${service.name}</option>`
  ).join("");
}

function setupQuickQuote() {
  const service = $("#qq-service");
  const quantity = $("#qq-quantity");
  const feedback = $("#quick-quote-feedback");

  $("#qq-calculate").addEventListener("click", () => {
    service.classList.remove("invalid");
    quantity.classList.remove("invalid");
    feedback.className = "quick-quote-feedback";
    feedback.textContent = "";

    const quantityValue = Number(quantity.value);
    if (!service.value || !Number.isInteger(quantityValue) || quantityValue < 1) {
      if (!service.value) service.classList.add("invalid");
      if (!Number.isInteger(quantityValue) || quantityValue < 1) quantity.classList.add("invalid");
      feedback.classList.add("error");
      feedback.textContent = "Select a service and enter a quantity of at least 1.";
      (!service.value ? service : quantity).focus();
      return;
    }

    $("#f-quantity").value = String(quantityValue);
    $("#f-complexity").value = $("#qq-complexity").value;
    $("#f-delivery").value = $("#qq-delivery").value;
    openQuote(service.value, 2);
  });

  [service, quantity].forEach((field) => {
    field.addEventListener("input", () => {
      field.classList.remove("invalid");
      feedback.textContent = "";
    });
  });
}

/* ====== Industries ====== */
function renderIndustries() {
  const grid = $("#industry-grid");
  grid.innerHTML = INDUSTRIES.map((ind) => `
    <article class="industry-card reveal">
      <div class="industry-icon">${ind.icon}</div>
      <h3 class="industry-name">${ind.name}</h3>
      ${ind.note ? `<p class="industry-note">${ind.note}</p>` : ""}
    </article>
  `).join("");
}

/* ====== FAQs ====== */
function renderFAQs() {
  const list = $("#faq-list");
  list.innerHTML = FAQS.map((f, i) => `
    <div class="faq-item reveal" data-faq="${i}">
      <button class="faq-q" aria-expanded="false" aria-controls="faq-a-${i}">
        <span>${f.q}</span>
        <svg class="faq-q-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
      </button>
      <div class="faq-a" id="faq-a-${i}">
        <div class="faq-a-inner">${f.a}</div>
      </div>
    </div>
  `).join("");

  $$(".faq-item", list).forEach((item) => {
    const btn = $(".faq-q", item);
    const ans = $(".faq-a", item);
    btn.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      $$(".faq-item").forEach((fi) => {
        fi.classList.remove("open");
        $(".faq-a", fi).style.maxHeight = null;
        $(".faq-q", fi).setAttribute("aria-expanded", "false");
      });
      if (!isOpen) {
        item.classList.add("open");
        ans.style.maxHeight = ans.scrollHeight + "px";
        btn.setAttribute("aria-expanded", "true");
      }
    });
  });
}

/* ====== Header scroll ====== */
function setupHeader() {
  const header = $("#site-header");
  window.addEventListener("scroll", () => {
    header.classList.toggle("scrolled", window.scrollY > 10);
  });
}

/* ====== Mobile nav ====== */
function setupNav() {
  const toggle = $("#nav-toggle");
  const nav = $("#site-nav");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
  });
  $$(".nav-link", nav).forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      toggle.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

/* ====== Modal ====== */
function setupModal() {
  const overlay = $("#quote-modal");
  const closeBtn = $("#modal-close");

  $$("[data-open-quote]").forEach((btn) => {
    btn.addEventListener("click", () => openQuote());
  });

  closeBtn.addEventListener("click", closeModal);
  $$("[data-close-modal]").forEach((btn) => btn.addEventListener("click", closeModal));
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) closeModal();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && overlay.classList.contains("open")) closeModal();
  });
}

function openQuote(serviceId, startStep = 1) {
  const overlay = $("#quote-modal");
  lastFocusedElement = document.activeElement;
  overlay.classList.add("open");
  overlay.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";

  if (serviceId) {
    selectService(serviceId);
  }
  goToStep(serviceId && startStep === 2 ? 2 : 1);
  window.setTimeout(() => $("#modal-close").focus(), 0);
}

function closeModal() {
  const overlay = $("#quote-modal");
  overlay.classList.remove("open");
  overlay.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  $("#modal-summary-side").classList.remove("mobile-open");
  $("#summary-toggle").classList.remove("open");
  $("#summary-toggle").setAttribute("aria-expanded", "false");
  if (lastFocusedElement && typeof lastFocusedElement.focus === "function") {
    lastFocusedElement.focus();
  }
}

/* ====== Quote wizard ====== */
function setupQuoteWizard() {
  const overlay = $("#quote-modal");

  $('[data-step-next]', overlay).addEventListener("click", () => {
    if (selectedServiceId) goToStep(2);
  });

  $("#project-form").addEventListener("submit", (e) => {
    e.preventDefault();
    if (validateProjectForm()) {
      collectProjectData();
      generateQuote();
      renderQuoteSummary();
      goToStep(3);
    }
  });

  $$("[data-step-prev]").forEach((btn) =>
    btn.addEventListener("click", () => goToStep(currentStep - 1))
  );

  $("#rfq-form").addEventListener("submit", (e) => {
    if (!validateRfqForm()) {
      e.preventDefault();
      return;
    }
    prepareSubmissionFields();
    $("#rfq-form").action = `https://formsubmit.co/${FORMSUBMIT_EMAIL}`;
    $("#submit-rfq").textContent = "Submitting...";
    $("#submit-rfq").disabled = true;
  });
}

function prepareSubmissionFields() {
  $("#hf-ref").value = quoteRef;
  $("#hf-service").value = getServiceName(selectedServiceId);
  $("#hf-estimate").value = quoteEstimate || "Custom quotation required after technical review.";
  $("#hf-quantity").value = projectData.quantity || "";
  $("#hf-date").value = projectData.deliveryDate || "";
  $("#hf-material").value = projectData.material || "";
  $("#hf-complexity").value = cap(projectData.complexity);
  $("#hf-delivery").value = projectData.delivery === "urgent" ? "Urgent" : "Standard";
  $("#hf-dimensions").value = projectData.dimensions || "";
  $("#hf-description").value = projectData.description || "";
  $("#hf-subject").value = `New PROTONEST RFQ — ${quoteRef} — ${getServiceName(selectedServiceId)}`;
  $("#hf-autoresponse").value = `Thank you for contacting PROTONEST. We received your quotation request ${quoteRef}. Our engineering team will review the technical requirements and contact you regarding the confirmed price and timeline.`;

  const nextField = $("#hf-next");
  const urlField = $("#hf-url");
  const isHosted = window.location.protocol === "http:" || window.location.protocol === "https:";
  nextField.disabled = !isHosted;
  urlField.disabled = !isHosted;
  if (isHosted) {
    const thankYouUrl = new URL("thank-you.html", window.location.href);
    thankYouUrl.search = "";
    thankYouUrl.hash = "";
    thankYouUrl.searchParams.set("ref", quoteRef);
    nextField.value = thankYouUrl.href;
    urlField.value = window.location.href;
  }
}

function goToStep(step) {
  currentStep = step;
  $$(".modal-step", $("#quote-modal")).forEach((s) => s.classList.add("hidden"));
  const target = $(`[data-step="${step}"]`, $("#quote-modal"));
  if (target) {
    target.classList.remove("hidden");
    $$(".modal-progress-step", $("#modal-progress")).forEach((progress, index) => {
      progress.classList.toggle("active", index === step - 1);
      progress.classList.toggle("done", index < step - 1);
    });
    $(".modal-form-side", $("#quote-modal")).scrollTop = 0;
  }
}

/* ====== Validation ====== */
function validateProjectForm() {
  const fields = ["f-material", "f-quantity", "f-complexity", "f-delivery", "f-dimensions", "f-date", "f-description"];
  let valid = true;
  fields.forEach((id) => {
    const el = $("#" + id);
    if (!el.checkValidity() || !el.value.trim()) {
      el.classList.add("invalid");
      valid = false;
    } else {
      el.classList.remove("invalid");
    }
  });
  const status = $("#project-error");
  status.textContent = valid ? "" : "Please complete every highlighted project field with a valid value.";
  if (!valid) {
    const firstInvalid = fields.map((id) => $("#" + id)).find((field) => field.classList.contains("invalid"));
    if (firstInvalid) firstInvalid.focus();
  }
  return valid;
}

function validateRfqForm() {
  const fields = ["f-name", "f-email", "f-mobile", "f-org", "f-city", "f-state", "f-consent"];
  let valid = true;
  fields.forEach((id) => {
    const el = $("#" + id);
    const hasValue = el.type === "checkbox" ? el.checked : Boolean(el.value && el.value.trim());
    if (!hasValue || !el.checkValidity()) {
      el.classList.add("invalid");
      valid = false;
    } else {
      el.classList.remove("invalid");
    }
  });
  const email = $("#f-email");
  if (email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
    email.classList.add("invalid");
    valid = false;
  }
  const fileInput = $("#f-file");
  if (fileInput.files.length > 0) {
    valid = validateFile(fileInput.files[0]) && valid;
  }
  const status = $("#rfq-error");
  status.textContent = valid ? "" : "Please complete the highlighted contact fields and check the attachment.";
  if (!valid) {
    const firstInvalid = fields.map((id) => $("#" + id)).find((field) => field.classList.contains("invalid"));
    if (firstInvalid) firstInvalid.focus();
  }
  return valid;
}

function setupFieldValidation() {
  $$("#project-form input, #project-form select, #project-form textarea, #rfq-form input").forEach((field) => {
    const eventName = field.type === "checkbox" || field.tagName === "SELECT" ? "change" : "input";
    field.addEventListener(eventName, () => {
      field.classList.remove("invalid");
      if (field.closest("#project-form")) $("#project-error").textContent = "";
      if (field.closest("#rfq-form")) $("#rfq-error").textContent = "";
    });
  });
}

function setMinimumDeliveryDate() {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  $("#f-date").min = now.toISOString().slice(0, 10);
}

/* ====== File input ====== */
function setupFileInput() {
  const fileInput = $("#f-file");
  const dropZone = $("#file-drop");

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length === 0) {
      resetFileHint();
      return;
    }
    if (!validateFile(fileInput.files[0])) fileInput.value = "";
  });

  dropZone.addEventListener("click", (event) => {
    if (event.target !== fileInput) fileInput.click();
  });
  dropZone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      fileInput.click();
    }
  });
  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.add("dragover");
    });
  });
  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.remove("dragover");
    });
  });
  dropZone.addEventListener("drop", (event) => {
    const files = event.dataTransfer && event.dataTransfer.files;
    if (!files || files.length === 0) return;
    try {
      fileInput.files = files;
    } catch (_error) {
      $("#file-hint").className = "file-hint error";
      $("#file-hint").textContent = "Please click the upload area to choose this file.";
      return;
    }
    if (!validateFile(fileInput.files[0])) fileInput.value = "";
  });
}

function validateFile(file) {
  const hint = $("#file-hint");
  const extension = file.name.includes(".") ? `.${file.name.split(".").pop().toLowerCase()}` : "";
  if (!ALLOWED_FILE_EXTENSIONS.includes(extension)) {
    hint.className = "file-hint error";
    hint.textContent = "Unsupported file. Use STL, STEP, STP, OBJ, 3MF, DXF, DWG, PDF, JPG, PNG or ZIP.";
    return false;
  }
  if (file.size > MAX_FILE_SIZE) {
    hint.className = "file-hint error";
    hint.textContent = `File is ${(file.size / 1048576).toFixed(1)} MB — the maximum is 10 MB.`;
    return false;
  }
  hint.className = "file-hint valid";
  hint.textContent = `${file.name} (${(file.size / 1048576).toFixed(2)} MB) — ready to upload.`;
  return true;
}

function resetFileHint() {
  const hint = $("#file-hint");
  hint.className = "file-hint";
  hint.textContent = "No file selected";
}

/* ====== Collect project data ====== */
function collectProjectData() {
  projectData = {
    material: $("#f-material").value,
    quantity: parseInt($("#f-quantity").value, 10),
    complexity: $("#f-complexity").value,
    delivery: $("#f-delivery").value,
    dimensions: $("#f-dimensions").value,
    deliveryDate: $("#f-date").value,
    description: $("#f-description").value,
  };
}

/* ====== Quote generation ====== */
function generateQuote() {
  const year = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000);
  quoteRef = `PN-${year}-${rand}`;

  const service = SERVICES.find((s) => s.id === selectedServiceId);
  if (service && service.instant && PRICING.instant[selectedServiceId]) {
    const cfg = PRICING.instant[selectedServiceId];
    const qty = projectData.quantity || 1;
    const cMult = PRICING.complexity[projectData.complexity] || 1;
    const uMult = projectData.delivery === "urgent" ? PRICING.urgentMultiplier : 1;

    const baseEstimate = (cfg.base + cfg.qty * qty) * cMult * uMult;
    const min = Math.round(baseEstimate * (1 - PRICING.rangeMargin) / 10) * 10;
    const max = Math.round(baseEstimate * (1 + PRICING.rangeMargin) / 10) * 10;
    quoteEstimate = `${formatINR(min)} – ${formatINR(max)}`;
  } else {
    quoteEstimate = null;
  }
}

function formatINR(amount) {
  return "\u20B9" + amount.toLocaleString("en-IN");
}

function getServiceName(id) {
  const s = SERVICES.find((sv) => sv.id === id);
  return s ? s.name : "—";
}

/* ====== Render quote summary ====== */
function renderQuoteSummary() {
  const summary = $("#quote-summary");
  const service = SERVICES.find((s) => s.id === selectedServiceId);
  const safeProject = {
    material: escapeHTML(projectData.material || "—"),
    quantity: escapeHTML(String(projectData.quantity || "—")),
    complexity: escapeHTML(cap(projectData.complexity)),
    delivery: projectData.delivery === "urgent" ? "Urgent" : "Standard",
    dimensions: escapeHTML(projectData.dimensions || "—"),
    deliveryDate: escapeHTML(projectData.deliveryDate || "—"),
  };

  let estimateHTML;
  if (quoteEstimate) {
    estimateHTML = `
      <div class="quote-estimate">
        <div class="quote-row"><span class="label">Indicative estimate</span></div>
        <div class="estimate-range">${quoteEstimate}</div>
      </div>
    `;
  } else {
    estimateHTML = `
      <div class="quote-estimate">
        <div class="quote-row"><span class="label">Estimate</span></div>
        <div class="estimate-range" style="font-size:1rem;">Custom quotation required after technical review.</div>
      </div>
    `;
  }

  summary.innerHTML = `
    <div class="quote-ref">${escapeHTML(quoteRef)}</div>
    <div class="quote-row"><span class="label">Service</span><span class="value">${escapeHTML(service ? service.name : "—")}</span></div>
    <div class="quote-row"><span class="label">Material</span><span class="value">${safeProject.material}</span></div>
    <div class="quote-row"><span class="label">Quantity</span><span class="value">${safeProject.quantity}</span></div>
    <div class="quote-row"><span class="label">Complexity</span><span class="value">${safeProject.complexity}</span></div>
    <div class="quote-row"><span class="label">Delivery</span><span class="value">${safeProject.delivery}</span></div>
    <div class="quote-row"><span class="label">Dimensions</span><span class="value">${safeProject.dimensions}</span></div>
    <div class="quote-row"><span class="label">Required by</span><span class="value">${safeProject.deliveryDate}</span></div>
    ${estimateHTML}
    <p class="quote-notice">Indicative estimate only. Final price, GST, delivery and feasibility will be confirmed after technical review.</p>
  `;

  const actionsDiv = document.createElement("div");
  actionsDiv.className = "quote-actions";
  actionsDiv.innerHTML = `
    <button class="btn btn-cta btn-sm" id="btn-print-quote" type="button" style="flex:1;">Print / Save Quote</button>
    <button class="btn btn-ghost btn-sm" id="btn-wa-quote" type="button" style="flex:1; color:#fff; border-color:rgba(255,255,255,0.3);">Continue on WhatsApp</button>
  `;
  summary.appendChild(actionsDiv);

  $("#btn-print-quote").addEventListener("click", printQuote);
  $("#btn-wa-quote").addEventListener("click", whatsappQuote);
}

function cap(str) {
  if (!str) return "—";
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function escapeHTML(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;",
  })[character]);
}

/* ====== Mobile quotation summary ====== */
function setupSummaryToggle() {
  const toggle = $("#summary-toggle");
  const summary = $("#modal-summary-side");
  toggle.addEventListener("click", () => {
    const open = summary.classList.toggle("mobile-open");
    toggle.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
  });
}

/* ====== Print quote ====== */
function printQuote() {
  const service = getServiceName(selectedServiceId);
  const estimateText = quoteEstimate || "Custom quotation required after technical review.";
  const safeMaterial = escapeHTML(projectData.material || "—");
  const safeQuantity = escapeHTML(String(projectData.quantity || "—"));
  const safeComplexity = escapeHTML(cap(projectData.complexity));
  const safeDimensions = escapeHTML(projectData.dimensions || "—");
  const safeDate = escapeHTML(projectData.deliveryDate || "—");

  const html = `
    <div style="padding:40px; font-family:'Inter',sans-serif; color:#07152B; max-width:700px;">
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:30px;">
        <svg width="36" height="36" viewBox="0 0 32 32"><rect width="32" height="32" rx="7" fill="#07152B" stroke="#1769E0" stroke-width="1.5"/><path d="M9 8h9a7 7 0 0 1 0 14h-4l5 6h-5l-5-6V8z" fill="none" stroke="#1769E0" stroke-width="2.5" stroke-linejoin="round"/><circle cx="18" cy="15" r="2.5" fill="#20B8F0"/></svg>
        <span style="font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:22px;">PROTONEST</span>
        <span style="margin-left:auto; font-size:13px; color:#5a677d;">Design. Prototype. Manufacture.</span>
      </div>
      <hr style="border:none; border-top:2px solid #1769E0; margin-bottom:24px;" />
      <h1 style="font-family:'Space Grotesk',sans-serif; font-size:24px; margin-bottom:8px;">Indicative Quotation</h1>
      <p style="font-size:14px; color:#5a677d; margin-bottom:24px;">Reference: <strong style="color:#1769E0; font-family:'Space Grotesk',sans-serif; font-size:16px;">${escapeHTML(quoteRef)}</strong></p>
      <table style="width:100%; border-collapse:collapse; font-size:14px;">
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d; width:40%;">Service</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; font-weight:600;">${escapeHTML(service)}</td></tr>
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d;">Material</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0;">${safeMaterial}</td></tr>
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d;">Quantity</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0;">${safeQuantity}</td></tr>
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d;">Complexity</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0;">${safeComplexity}</td></tr>
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d;">Delivery speed</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0;">${projectData.delivery === "urgent" ? "Urgent" : "Standard"}</td></tr>
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d;">Dimensions</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0;">${safeDimensions}</td></tr>
        <tr><td style="padding:10px 0; border-bottom:1px solid #e3e9f0; color:#5a677d;">Required by</td><td style="padding:10px 0; border-bottom:1px solid #e3e9f0;">${safeDate}</td></tr>
      </table>
      <div style="margin-top:24px; padding:20px; background:#f0f4f8; border-radius:12px;">
        <p style="font-size:13px; color:#5a677d; margin-bottom:8px;">Indicative estimate</p>
        <p style="font-family:'Space Grotesk',sans-serif; font-size:22px; font-weight:700; color:#1769E0; margin-bottom:8px;">${estimateText}</p>
        <p style="font-size:12px; color:#5a677d; font-style:italic;">Indicative estimate only. Final price, GST, delivery and feasibility will be confirmed after technical review.</p>
      </div>
      <p style="margin-top:30px; font-size:12px; color:#7c8aa0; text-align:center;">PROTONEST | ${CONTACT.email} | ${CONTACT.phone}<br/>Generated on ${new Date().toLocaleDateString("en-IN")}</p>
    </div>
  `;

  $("#print-quote").innerHTML = html;
  window.print();
}

/* ====== WhatsApp quote ====== */
function whatsappQuote() {
  const service = getServiceName(selectedServiceId);
  const estimateText = quoteEstimate || "Custom quotation required after technical review.";
  const message = [
    "Hello PROTONEST, I would like to proceed with my project.",
    "",
    `Reference: ${quoteRef}`,
    `Service: ${service}`,
    `Indicative estimate: ${estimateText}`,
    "",
    "Please review and confirm the next steps.",
  ].join("\n");
  window.open(`${CONTACT.whatsappLink}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}

/* ====== Back to top ====== */
function setupBackToTop() {
  const btn = $("#back-to-top");
  window.addEventListener("scroll", () => {
    btn.classList.toggle("visible", window.scrollY > 500);
  });
  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

/* ====== Scroll reveal ====== */
function setupReveal() {
  if (!("IntersectionObserver" in window)) {
    $$(".reveal").forEach((element) => element.classList.add("in"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
  );
  $$(".reveal").forEach((el) => observer.observe(el));
}
